<template>
  <ReportForm />
</template>

<script setup>
import ReportForm from "./components/ReportForm.vue";
</script>