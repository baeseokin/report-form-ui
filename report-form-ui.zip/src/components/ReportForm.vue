<template>
  <div class="min-h-screen bg-gray-100 flex flex-col items-center p-6 gap-6">
    <div class="w-full max-w-2xl bg-white shadow-lg rounded-2xl p-6">
      <h1 class="text-2xl font-bold mb-4">📑 보고서 생성기</h1>

      <div class="space-y-4">
        <input type="text" placeholder="제목" v-model="title" class="w-full border rounded-lg p-2" />
        <input type="text" placeholder="작성자" v-model="author" class="w-full border rounded-lg p-2" />
        <input type="date" v-model="date" class="w-full border rounded-lg p-2" />

        <select v-model="category" class="w-full border rounded-lg p-2">
          <option>General</option>
          <option>기술</option>
          <option>교육</option>
          <option>연구</option>
        </select>

        <textarea placeholder="내용을 입력하세요" rows="6" v-model="content" class="w-full border rounded-lg p-2"></textarea>

        <button @click="generateReport" class="w-full bg-blue-600 text-white rounded-lg p-2 hover:bg-blue-700">
          보고서 생성
        </button>
      </div>
    </div>

    <transition name="fade" mode="out-in">
      <div v-if="report" key="report" class="w-full max-w-2xl">
        <div class="bg-white shadow-lg border border-gray-200 rounded-2xl p-6">
          <h2 class="text-xl font-bold mb-2">{{ report.title }}</h2>
          <p class="text-sm text-gray-500 mb-4">작성자: {{ report.author }} | 날짜: {{ report.date }}</p>
          <p class="font-semibold mb-2">카테고리: {{ report.category }}</p>
          <p class="whitespace-pre-line">{{ report.content }}</p>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup>
import { ref } from "vue";

const title = ref("");
const author = ref("");
const date = ref(new Date().toISOString().slice(0, 10));
const category = ref("General");
const content = ref("");
const report = ref(null);

const generateReport = () => {
  report.value = {
    title: title.value,
    author: author.value,
    date: date.value,
    category: category.value,
    content: content.value,
  };
};
</script>

<style>
.fade-enter-active, .fade-leave-active {
  transition: opacity 0.5s, transform 0.5s;
}
.fade-enter-from, .fade-leave-to {
  opacity: 0;
  transform: translateY(20px);
}
</style>